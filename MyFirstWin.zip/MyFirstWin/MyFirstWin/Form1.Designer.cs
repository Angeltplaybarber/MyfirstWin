﻿namespace MyFirstWin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListResult = new ListBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            TxtBox1 = new TextBox();
            TxtBox2 = new TextBox();
            ButtonSum = new Button();
            ButtonSubs = new Button();
            ButtonClear = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // ListResult
            // 
            ListResult.BackColor = Color.FromArgb(128, 255, 255);
            ListResult.FormattingEnabled = true;
            ListResult.ItemHeight = 19;
            ListResult.Location = new Point(20, 39);
            ListResult.Margin = new Padding(4);
            ListResult.Name = "ListResult";
            ListResult.Size = new Size(288, 251);
            ListResult.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(68, 13);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(360, 23);
            label1.TabIndex = 1;
            label1.Text = "Suma o Resta 2 numeros de tu preferencia";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(95, 138);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(88, 19);
            label2.TabIndex = 2;
            label2.Text = "Primer Valor:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(95, 218);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(101, 19);
            label3.TabIndex = 3;
            label3.Text = "Segundo Valor:";
            // 
            // TxtBox1
            // 
            TxtBox1.BackColor = Color.Tan;
            TxtBox1.Location = new Point(201, 138);
            TxtBox1.Margin = new Padding(4);
            TxtBox1.Name = "TxtBox1";
            TxtBox1.Size = new Size(383, 26);
            TxtBox1.TabIndex = 4;
            // 
            // TxtBox2
            // 
            TxtBox2.BackColor = Color.Tan;
            TxtBox2.Location = new Point(201, 218);
            TxtBox2.Margin = new Padding(4);
            TxtBox2.Name = "TxtBox2";
            TxtBox2.Size = new Size(383, 26);
            TxtBox2.TabIndex = 5;
            // 
            // ButtonSum
            // 
            ButtonSum.BackColor = Color.FromArgb(128, 255, 255);
            ButtonSum.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ButtonSum.Location = new Point(5, 16);
            ButtonSum.Margin = new Padding(4);
            ButtonSum.Name = "ButtonSum";
            ButtonSum.Size = new Size(96, 68);
            ButtonSum.TabIndex = 6;
            ButtonSum.Text = "Suma";
            ButtonSum.UseVisualStyleBackColor = false;
            ButtonSum.Click += ButtonSum_Click;
            // 
            // ButtonSubs
            // 
            ButtonSubs.BackColor = Color.Lime;
            ButtonSubs.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ButtonSubs.Location = new Point(216, 16);
            ButtonSubs.Margin = new Padding(4);
            ButtonSubs.Name = "ButtonSubs";
            ButtonSubs.Size = new Size(96, 68);
            ButtonSubs.TabIndex = 7;
            ButtonSubs.Text = "Resta";
            ButtonSubs.UseVisualStyleBackColor = false;
            ButtonSubs.Click += ButtonSubs_Click;
            // 
            // ButtonClear
            // 
            ButtonClear.BackColor = Color.Red;
            ButtonClear.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ButtonClear.Location = new Point(412, 16);
            ButtonClear.Margin = new Padding(4);
            ButtonClear.Name = "ButtonClear";
            ButtonClear.Size = new Size(96, 68);
            ButtonClear.TabIndex = 8;
            ButtonClear.Text = "Limpiar";
            ButtonClear.UseVisualStyleBackColor = false;
            ButtonClear.Click += ButtonClear_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Tan;
            panel1.Controls.Add(ListResult);
            panel1.ForeColor = SystemColors.ControlText;
            panel1.Location = new Point(637, 116);
            panel1.Name = "panel1";
            panel1.Size = new Size(328, 326);
            panel1.TabIndex = 9;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Tan;
            panel2.Controls.Add(label1);
            panel2.ForeColor = SystemColors.ControlText;
            panel2.Location = new Point(238, 30);
            panel2.Name = "panel2";
            panel2.Size = new Size(495, 49);
            panel2.TabIndex = 10;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Tan;
            panel3.Controls.Add(ButtonClear);
            panel3.Controls.Add(ButtonSum);
            panel3.Controls.Add(ButtonSubs);
            panel3.ForeColor = SystemColors.ControlText;
            panel3.Location = new Point(95, 309);
            panel3.Name = "panel3";
            panel3.Size = new Size(514, 97);
            panel3.TabIndex = 11;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Snow;
            ClientSize = new Size(1029, 570);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(TxtBox2);
            Controls.Add(TxtBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox ListResult;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox TxtBox1;
        private TextBox TxtBox2;
        private Button ButtonSum;
        private Button ButtonSubs;
        private Button ButtonClear;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
    }
}
