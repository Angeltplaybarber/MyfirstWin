namespace MyFirstWin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            ListResult.Items.Clear();
        }

        private void ButtonSum_Click(object sender, EventArgs e)
        {
            try
            {
                decimal value1 = Decimal.Parse(TxtBox1.Text);
                decimal value2 = Decimal.Parse(TxtBox2.Text);
                decimal Result = value1 + value2;
                ListResult.Items.Add(Result);
                TxtBox1.Text = "";
                TxtBox2.Text = "";
            }
            catch (FormatException ex) {
                MessageBox.Show($"Porfavor inserta un valor", "Error",MessageBoxButtons.OK ,MessageBoxIcon.Error);
            }
        }

        private void ButtonSubs_Click(object sender, EventArgs e)
        {
            try
            {
                decimal value1 = Decimal.Parse(TxtBox1.Text);
                decimal value2 = Decimal.Parse(TxtBox2.Text);
                decimal Result = value1 - value2;
                ListResult.Items.Add(Result);
                TxtBox1.Text = "";
                TxtBox2.Text = "";
            }catch(FormatException ex)
            {
                MessageBox.Show($"Por favor inserta un valor", "Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
